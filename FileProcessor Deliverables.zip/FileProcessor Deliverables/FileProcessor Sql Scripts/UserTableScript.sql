CREATE TABLE Users
( Id int IDENTITY(1, 1) PRIMARY KEY,
  Email varchar(100) NOT NULL,
  Password varchar(30) NOT NULL
  );