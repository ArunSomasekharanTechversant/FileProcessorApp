﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileProcessingConsoleApp.Repository.Interface
{
    public interface IProcessDataRepository
    {
         Task InsertData(string[] values);
         Task UpdateFileStatus(int fileId);
    }
}
