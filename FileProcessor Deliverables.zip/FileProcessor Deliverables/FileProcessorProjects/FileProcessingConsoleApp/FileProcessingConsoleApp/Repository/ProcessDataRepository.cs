﻿
using System.Data.SqlClient;
using System.Data;
using FileProcessingConsoleApp.Repository.Interface;
using Dapper;
using System.Data.Common;
using System.Xml.Linq;

namespace FileProcessingConsoleApp.Repository
{
    public class ProcessDataRepository: IProcessDataRepository
    {
        private readonly string _connectionString;

        public ProcessDataRepository(string connectionString)
        {
            _connectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
        }

        public async Task InsertData(string[] values)
        {
           string query = "INSERT INTO FilesData (FileId, FirstName,LastName,Age) VALUES ('" + values[0] + "','" + values[1] + "','" + values[2] + "','" + values[3] + "'); SELECT SCOPE_IDENTITY()";
            ExecuteQuery(query);
        }

        public async Task UpdateFileStatus(int fileId)
        {
            string query = "UPDATE Files SET FileStatus='Completed' WHERE Id ="+ fileId;
            ExecuteQuery(query);
        }

        private async void ExecuteQuery(string query)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                try
                {
                    await connection.OpenAsync();
                    connection.Execute(query);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error saving CSV data: {ex.Message}");
                    // Handle exception (log, throw, etc.)
                }
                finally
                {
                    if (connection.State == ConnectionState.Open)
                    {
                        connection.Close();
                    }
                }
            }
        }
    }
}
