﻿using FileProcessingConsoleApp.Repository;
using FileProcessingConsoleApp.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileProcessingConsoleApp.Service
{
    public class MessageProcessingService
    {
        private readonly ProcessDataRepository _repository;

        public MessageProcessingService(ProcessDataRepository repository)
        {
            _repository = repository ?? throw new ArgumentNullException(nameof(repository));
        }

       
        public async Task ProcessCSVMessage(string csvMessage)
        {
            // Parse CSV message
            var values = csvMessage.Split(',');

            // Save to database using repository
          await  _repository.InsertData(values); 
        }

        public async Task UpdateFileStatus(int fileId)
        {
            await _repository.UpdateFileStatus(fileId);
        }
    }
}
