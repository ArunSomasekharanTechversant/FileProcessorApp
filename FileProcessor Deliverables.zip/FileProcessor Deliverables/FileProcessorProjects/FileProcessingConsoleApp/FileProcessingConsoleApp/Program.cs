﻿using FileProcessingConsoleApp.Repository;
using FileProcessingConsoleApp.Service;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var configuration = new ConfigurationBuilder()
                    .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                    .Build();

string rabbitMQHostName = configuration.GetSection("rabbitMQHostName").Value;
string queueName = configuration.GetSection("rabbitqueueName").Value;

var host = Host.CreateDefaultBuilder(args)
            .ConfigureServices((context, services) =>
            {
                // Register repository and other services
                services.AddSingleton(configuration);
               services.AddSingleton<RabbitMQClientService>(provider =>
                    new RabbitMQClientService(rabbitMQHostName, queueName));
                services.AddTransient<ProcessDataRepository>((provider) =>
                 new ProcessDataRepository(configuration.GetConnectionString("DefaultConnection")));
                services.AddTransient<MessageProcessingService>();
            })
            .Build();

// Start consuming messages from RabbitMQ
var rabbitMQService = host.Services.GetRequiredService<RabbitMQClientService>();
var messageProcessingService = host.Services.GetRequiredService<MessageProcessingService>();
int fileId = 0;
int count = 0;
rabbitMQService.StartConsumingMessages(async (message) =>
{
    Console.WriteLine($"Received message: {message}");

    // Process and save CSV data using repository
    await messageProcessingService.ProcessCSVMessage(message);

    if (count == 0)
    {
        var values = message.Split(',');
        fileId = int.Parse(values[0]);
        await messageProcessingService.UpdateFileStatus(fileId);
    }
  
});

// Keep the application running
await Task.Delay(Timeout.Infinite);
   