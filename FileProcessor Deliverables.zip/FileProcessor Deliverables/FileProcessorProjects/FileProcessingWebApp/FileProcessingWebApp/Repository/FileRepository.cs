﻿using Dapper;
using FileProcessingWebApp.Models;
using FileProcessingWebApp.Repository.Interfaces;
using System.Data;
using System.Data.Common;

namespace FileProcessingWebApp.Repository
{
    public class FileRepository: IFileRepository
    {
        private readonly IDbConnection _dbConnection;

        public FileRepository(IDbConnection db)
        {
            _dbConnection = db;
        }

        public async Task<IEnumerable<Files>> GetFilesByUserIdAsync(int userId)
        {
            string query = "SELECT * FROM Files WHERE UserId = @UserId";
            return await _dbConnection.QueryAsync<Files>(query, new { UserId = userId });
        }

        public async Task<int> CreateProcessedFileAsync(Files file)
        {
            string query = "INSERT INTO Files (UserId, FileName, FileStatus) VALUES ('"+ file.UserId+ "','"+ file.FileName+"','"+file.FileStatus+"'); SELECT SCOPE_IDENTITY()";
            return await _dbConnection.ExecuteScalarAsync<int>(query);
        }

    }
}
