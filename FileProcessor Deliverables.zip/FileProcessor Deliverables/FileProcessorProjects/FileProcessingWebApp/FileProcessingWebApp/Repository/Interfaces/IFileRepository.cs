﻿using FileProcessingWebApp.Models;

namespace FileProcessingWebApp.Repository.Interfaces
{
    public interface IFileRepository
    {
        Task<IEnumerable<Files>> GetFilesByUserIdAsync(int userId);
        Task<int> CreateProcessedFileAsync(Files file);
    }
}
