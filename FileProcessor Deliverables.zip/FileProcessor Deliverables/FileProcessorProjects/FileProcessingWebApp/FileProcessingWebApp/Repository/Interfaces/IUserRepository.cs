﻿using FileProcessingWebApp.Models;

namespace FileProcessingWebApp.Repository.Interfaces
{
    public interface IUserRepository
    {
        Task<User> GetUserByUsernameAsync(string username);
        Task<int> CreateUserAsync(User user);
        Task<User> AuthenticateUser(string email, string password);
        Task<User> IsUserExists(string email);
    }
}
