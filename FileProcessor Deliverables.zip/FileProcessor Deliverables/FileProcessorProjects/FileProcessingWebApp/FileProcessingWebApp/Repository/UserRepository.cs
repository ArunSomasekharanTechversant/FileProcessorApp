﻿using Dapper;
using FileProcessingWebApp.Models;
using FileProcessingWebApp.Repository.Interfaces;
using System.Data;
using System.Data.Common;

namespace FileProcessingWebApp.Repository
{
    public class UserRepository: IUserRepository
    {
        private readonly IDbConnection _dbConnection;

        public UserRepository(IDbConnection db)
        {
            _dbConnection = db;
        }

        public async Task<User> GetUserByUsernameAsync(string username)
        {
            string query = "SELECT * FROM Users WHERE Username = @Username";
            return await _dbConnection.QueryFirstOrDefaultAsync<User>(query, new { Username = username });
        }

        public async Task<int> CreateUserAsync(User user)
        {
            string query = "INSERT INTO Users (Email, Password) VALUES ('"+ user.Email+"','"+ user.Password+"'); SELECT SCOPE_IDENTITY()";
            return await _dbConnection.ExecuteScalarAsync<int>(query);
        }

        public async Task<User> AuthenticateUser(string email, string password)
        {
            string query = "SELECT * FROM Users WHERE Email = @email and Password=@password";
            return await _dbConnection.QueryFirstOrDefaultAsync<User>(query, new { Email = email,Password = password });
        }

        public async Task<User> IsUserExists(string email)
        {
            string query = "SELECT * FROM Users WHERE Email = @email";
            return await _dbConnection.QueryFirstOrDefaultAsync<User>(query, new { Email = email });
        }

    }
}
