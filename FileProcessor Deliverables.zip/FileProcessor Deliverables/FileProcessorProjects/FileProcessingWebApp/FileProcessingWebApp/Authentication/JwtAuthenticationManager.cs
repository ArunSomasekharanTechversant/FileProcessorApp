﻿using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace FileProcessingWebApp.Authentication
{
    public class JwtAuthenticationManager : IJwtAuthenticationManager
    {
        private readonly IConfiguration _configuration;

        /// <summary>
        /// JwtAuthenticationManager constructor
        /// </summary>
        /// <param name="configuration"></param>
        public JwtAuthenticationManager(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        /// <summary>
        /// GenerateSecretKey- method to generate secret key,which can be added in the appsettings
        /// </summary>
        /// <param name="keySizeInBytes"></param>
        /// <returns></returns>
        public string GenerateSecretKey(int keySizeInBytes)
        {
            byte[] keyBytes = new byte[keySizeInBytes];
            using (var rng = new RNGCryptoServiceProvider())
            {
                rng.GetBytes(keyBytes);
            }
            return Convert.ToBase64String(keyBytes);
        }

        /// <summary>
        /// Generates token on login
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        public string GenerateToken(string email)
        {
            var jwtSettings = _configuration.GetSection("JwtSettings");
           var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings["Secret"]));
           // string secretKey = GenerateSecretKey(32); this line can be used to generate secretkey and store in appsettings
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                new Claim(ClaimTypes.Email, email)
                    // Add more claims as needed (e.g., roles)
                }),
                Expires = DateTime.UtcNow.AddMinutes(Convert.ToDouble(jwtSettings["ExpirationInMinutes"])),
                SigningCredentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256Signature)
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);

            return tokenHandler.WriteToken(token);
        }

        /// <summary>
        /// Authenticate by passing token
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        public bool Authenticate(string token)
        {           

            if (token == null)
            {
                return false;
            }

            // Validate and use token for authorization
            var tokenHandler = new JwtSecurityTokenHandler();
            var jwtSettings = _configuration.GetSection("JwtSettings");
            var key = Encoding.UTF8.GetBytes(jwtSettings["Secret"]);

            try
            {
                // Validate token
                var tokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = false, // Modify as needed
                    ValidateAudience = false, // Modify as needed
                    ValidateLifetime = true,
                };

                SecurityToken validatedToken;
                var principal = tokenHandler.ValidateToken(token, tokenValidationParameters, out validatedToken);

                // Optionally, you can access claims from principal.Claims
                //var userId = principal.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value;
                //var username = principal.Identity?.Name;

                // Use userId or username as needed for authorization logic
                // For example, check if the user has necessary permissions
                if (validatedToken != null)
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
               return false;
            }
        }
    }
}