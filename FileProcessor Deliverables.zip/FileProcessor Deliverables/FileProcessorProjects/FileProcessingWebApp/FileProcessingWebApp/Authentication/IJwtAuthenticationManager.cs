﻿namespace FileProcessingWebApp.Authentication
{
    public interface IJwtAuthenticationManager
    {
        string GenerateToken(string email);
        bool Authenticate(string token);
    }
}
