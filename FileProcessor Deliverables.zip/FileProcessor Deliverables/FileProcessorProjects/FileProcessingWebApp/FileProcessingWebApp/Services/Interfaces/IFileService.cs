﻿using FileProcessingWebApp.Models;

namespace FileProcessingWebApp.Services.Interfaces
{
    public interface IFileService
    {
        Task<IEnumerable<Files>> GetFilesByUserIdAsync(int userId);
        Task<int> CreateProcessedFileAsync(Files file);
    }
}
