﻿using FileProcessingWebApp.Models;

namespace FileProcessingWebApp.Services.Interfaces
{
    public interface IUserService
    {
        Task<User> GetUserByUsernameAsync(string username);
        Task<int> CreateUserAsync(User user);
        Task<User> AuthenticateUserAsync(string email, string password);
        Task<User> IsUserExistsAsync(string email);
    }
}
