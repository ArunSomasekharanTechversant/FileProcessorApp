﻿using FileProcessingWebApp.Models;
using FileProcessingWebApp.Repository.Interfaces;
using FileProcessingWebApp.Services.Interfaces;

namespace FileProcessingWebApp.Services
{
    public class UserService: IUserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public async Task<User> GetUserByUsernameAsync(string username)
        {
            return await _userRepository.GetUserByUsernameAsync(username);
        }

        public async Task<int> CreateUserAsync(User user)
        {
            return await _userRepository.CreateUserAsync(user);
        }

        public async Task<User> AuthenticateUserAsync(string email, string password)
        {
            return await _userRepository.AuthenticateUser(email,  password);
        }

        public async Task<User> IsUserExistsAsync(string email)
        {
            return await _userRepository.IsUserExists(email);
        }
    }
}
