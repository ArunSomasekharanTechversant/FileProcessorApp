﻿using FileProcessingWebApp.Models;
using FileProcessingWebApp.Repository.Interfaces;
using FileProcessingWebApp.Services.Interfaces;

namespace FileProcessingWebApp.Services
{
    public class FileService: IFileService
    {
        private readonly IFileRepository _fileRepository;

        public FileService(IFileRepository fileRepository)
        {
            _fileRepository = fileRepository;
        }

        public async Task<IEnumerable<Files>> GetFilesByUserIdAsync(int userId)
        {
            return await _fileRepository.GetFilesByUserIdAsync(userId);
        }

        public async Task<int> CreateProcessedFileAsync(Files file)
        {
            return await _fileRepository.CreateProcessedFileAsync(file);
        }
    }
}
