﻿using FileProcessingWebApp.Authentication;
using FileProcessingWebApp.Models;
using FileProcessingWebApp.Services.Interfaces;
using FileProcessingWebApp.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace FileProcessingWebApp.Controllers
{
    public class UserController : Controller
    {

        #region Private Variables
        private readonly IUserService _userService;
        private readonly ILogger<UserController> _logger;
        private readonly IJwtAuthenticationManager _jwtAuthenticationManager;
        #endregion

        #region Constructor
        /// <summary>
        /// UserController constructor
        /// </summary>
        /// <param name="userService"></param>
        /// <param name="logger"></param>
        /// <param name="jwtAuthenticationManager"></param>
        public UserController(IUserService userService,ILogger<UserController> logger, IJwtAuthenticationManager jwtAuthenticationManager)
        {
            _userService = userService;
            _logger = logger;
            _jwtAuthenticationManager = jwtAuthenticationManager;
        }
        #endregion

        #region Action methods
        /// <summary>
        /// Login -method to redirect to login page
        /// </summary>
        /// <returns>Task<IActionResult></returns>
        public async Task<IActionResult> Login()
        {
            try
            {
                return View("/Views/Account/Login.cshtml");
            }
            catch (Exception ex)
            {
                _logger.LogError($"An error occurred: {ex.Message}");
                return View("Error");
            }
        }

        /// <summary>
        /// SignUpPage- method to redirect to signup page
        /// </summary>
        /// <returns>Task<IActionResult></returns>
        public async Task<IActionResult> SignUpPage()
        {
            try
            {
                return View("/Views/Account/Signup.cshtml");
            }
            catch (Exception ex)
            {
                _logger.LogError($"An error occurred: {ex.Message}");
                return View("Error");
            }
        }

        /// <summary>
        /// SignUp method to create new user accounts
        /// </summary>
        /// <param name="user"></param>
        /// <returns>Task<IActionResult></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SignUp(SignUpViewModel user)
        {
            try
            {
                if (ModelState.IsValid)
                { 
                    User userData = new User();
                    userData.Email = user.Email;
                    userData.Password = user.Password;
                    // Validate and create user
                    var userExists= await _userService.IsUserExistsAsync(userData.Email);
                    if (userExists == null)
                    {
                        var userId = await _userService.CreateUserAsync(userData);
                        if (userId > 0)
                        {
                            ViewBag.message = "Account created Successfully";
                            return View("/Views/Account/Login.cshtml");
                        }
                    }
                    else
                    {
                        ViewBag.message = "User Already Exists!";
                        return View("/Views/Account/Signup.cshtml");
                    }
                    
                }
               
                return View("/Views/Account/Signup.cshtml");
            }
            catch (Exception ex)
            {
                _logger.LogError($"An error occurred: {ex.Message}");
                ViewBag.message = "Account creation failed!";
                return View("Error");
            }
           
        }

        /// <summary>
        /// Login method which redirects to home page ,if authentication succeed
        /// </summary>
        /// <param name="user"></param>
        /// <returns>Task<IActionResult></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel user)
        {
            try
            {
                User userDetails = new User();
                if (ModelState.IsValid)
                {
                    // Validate and create user
                    userDetails = await _userService.AuthenticateUserAsync(user.Email, user.Password);

                    if (userDetails != null)
                    {
                        ViewBag.LoginMessage = "Home";
                        var token = _jwtAuthenticationManager.GenerateToken(user.Email);
                        HttpContext.Session.SetString("JwtToken", token);
                        HttpContext.Session.SetInt32("UserId", userDetails.Id);
                        return RedirectToAction("Index", "Home");
                    }

                }
                ViewBag.LoginMessage = "Login failed!";
                return View("/Views/Account/Login.cshtml");

            }
            catch (Exception ex)
            {
                _logger.LogError($"An error occurred: {ex.Message}");
                return View("Error");
            }
        }
        #endregion

    }
}
