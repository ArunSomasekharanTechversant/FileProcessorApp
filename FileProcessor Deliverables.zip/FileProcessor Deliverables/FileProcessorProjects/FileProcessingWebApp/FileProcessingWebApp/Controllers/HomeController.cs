using FileProcessingWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Text;
using RabbitMQ.Client;
using FileProcessingWebApp.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using FileProcessingWebApp.Authentication;


namespace FileProcessingWebApp.Controllers
{
    public class HomeController : Controller
    {
        #region Private Variables
        private readonly ConnectionFactory _factory;
        private readonly IConnection _connection;
        private readonly IModel _channel;
        private readonly ILogger<HomeController> _logger;
        private readonly IFileService _fileService;
        private readonly IConfiguration _configuration;
        private readonly IJwtAuthenticationManager _jwtAuthenticationManager;
        #endregion

        #region Constructor
        /// <summary>
        /// HomeController constructor
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="fileService"></param>
        /// <param name="configuration"></param>
        /// <param name="jwtAuthenticationManager"></param>
        public HomeController(ILogger<HomeController> logger, IFileService fileService, IConfiguration configuration, IJwtAuthenticationManager jwtAuthenticationManager)
        {   
             _configuration = configuration;
            _factory = new ConnectionFactory() { HostName = _configuration.GetSection("rabbitMQHostName").Value };
            _connection = _factory.CreateConnection();
            _channel = _connection.CreateModel();
            _logger = logger;
            _fileService = fileService;
            _jwtAuthenticationManager = jwtAuthenticationManager;

        }
        #endregion

        #region Action Methods
        /// <summary>
        /// Index-this method is called after the authentication success
        /// </summary>
        /// <returns>Task<IActionResult></returns>
        public async Task<IActionResult> Index()
        {
            // Retrieve JWT token from session
            var token = HttpContext.Session.GetString("JwtToken");
            var authenticationSucceed = _jwtAuthenticationManager.Authenticate(token);
            if (!authenticationSucceed)
            {
               return RedirectToAction("Login", "User");
            }
            ViewBag.LoginMessage = "Home";
            int userId = HttpContext.Session.GetInt32("UserId")??0;
            ViewBag.Files = await _fileService.GetFilesByUserIdAsync(userId).ConfigureAwait(false);
            ViewBag.UploadSuccess = HttpContext.Session.GetString("FileUploadSuccess");
            HttpContext.Session.Remove("FileUploadSuccess");
            return View();
        }

        /// <summary>
        /// Method to uplod csv file data RabbitMQ  queue 
        /// </summary>
        /// <param name="file"></param>
        /// <returns>Task<IActionResult></returns>
        [HttpPost]
        public async Task<IActionResult> Upload(IFormFile file)
        {
            // Retrieve JWT token from session
            var token = HttpContext.Session.GetString("JwtToken");
            var authenticationSucceed= _jwtAuthenticationManager.Authenticate(token);
            if (!authenticationSucceed)
            {
                return  RedirectToAction("Login", "User");
            }
            ViewBag.LoginMessage = "Home";
            int userId = HttpContext.Session.GetInt32("UserId") ?? 0;

            if (file != null && file.Length > 0)
            {
                try
                { 
                    Files FileDetails = new Models.Files() { FileName=file.FileName,UserId= userId, FileStatus="Inprogress" };
                    var fileId = await _fileService.CreateProcessedFileAsync(FileDetails).ConfigureAwait(false);
                    using (var memoryStream = new MemoryStream())
                    {
                        await file.CopyToAsync(memoryStream);
                        memoryStream.Position = 0;

                        // Read CSV content
                        using (var reader = new StreamReader(memoryStream))
                        {
                            while (!reader.EndOfStream)
                            {
                                var line = reader.ReadLine();
                                if (!string.IsNullOrEmpty(line))
                                {
                                    SendToRabbitMQ(string.Concat(fileId + ",", line));
                                }
                            }
                        }
                        ViewBag.UploadSuccess = "CSV file data sent to RabbitMQ successfully.";
                    }
                }
                catch (Exception ex)
                {
                    ViewBag.Error = "Error uploading file: " + ex.Message;
                    return View("Error");
                }
            }
            else
            {
                ViewBag.Error = "Please select a file to upload.";
            }
            HttpContext.Session.SetString("FileUploadSuccess", "CSV file data sent to RabbitMQ successfully.");
            ViewBag.Files = await _fileService.GetFilesByUserIdAsync(userId).ConfigureAwait(false);
            return RedirectToAction("Index", "Home");
        }

        /// <summary>
        /// Sends messagetTo RabbitMQ
        /// </summary>
        /// <param name="message"></param>
        private void SendToRabbitMQ(string message)
        {
            var queueName = _configuration.GetSection("rabbitqueueName").Value;
            _channel.QueueDeclare(queue: queueName,
                                  durable: false,
                                  exclusive: false,
                                  autoDelete: false,
                                  arguments: null);

            var body = Encoding.UTF8.GetBytes(message);

            _channel.BasicPublish(exchange: "",
                                  routingKey: queueName,
                                  basicProperties: null,
                                  body: body);
        }

        /// <summary>
        /// Logout- clears session and redirects to login page
        /// </summary>
        /// <returns>Task<IActionResult></returns>
        public async Task<IActionResult> Logout()
        {
            HttpContext.Session.Clear();

            // Redirect to the login page after logout
            return RedirectToAction("Login", "User");
        }

        /// <summary>
        /// Dispose- method closes the RabbitMQ channel and connection
        /// </summary>
        /// <param name="disposing"></param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _channel.Close();
                _connection.Close();
            }
            base.Dispose(disposing);
        }

        #endregion

    }
}
