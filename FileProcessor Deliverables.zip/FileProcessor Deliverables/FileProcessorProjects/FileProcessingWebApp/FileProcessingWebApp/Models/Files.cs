﻿namespace FileProcessingWebApp.Models
{
    public class Files
    {
        public int Id { get; set; }
        public string FileName { get; set; }
        public string FileStatus { get; set; }
        public int UserId { get; set; }
    }
}
