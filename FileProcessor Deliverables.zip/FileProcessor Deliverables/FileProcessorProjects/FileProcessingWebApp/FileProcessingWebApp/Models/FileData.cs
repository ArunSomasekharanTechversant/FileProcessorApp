﻿namespace FileProcessingWebApp.Models
{
    public class FileData
    {
        public int Id { get; set; }
        public int FileId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public int Age { get; set; }

    }
}
