using FileProcessingWebApp.Authentication;
using FileProcessingWebApp.Controllers;
using FileProcessingWebApp.Models;
using FileProcessingWebApp.Services.Interfaces;
using FileProcessingWebApp.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using Moq;

namespace FileProcessorTests
{
    public class UserControllerTests
    {

        private readonly Mock<IUserService> _mockUserService;
        private readonly Mock<IJwtAuthenticationManager> _mockJwtAuthenticationManager;
        private readonly UserController _controller;

        public UserControllerTests()
        {
            _mockUserService = new Mock<IUserService>();
            _mockJwtAuthenticationManager = new Mock<IJwtAuthenticationManager>();
            var mockLogger = new Mock<ILogger<UserController>>();
            _controller = new UserController(_mockUserService.Object, mockLogger.Object, _mockJwtAuthenticationManager.Object);
        }

        [Fact]
        public async Task Login_Returns_ViewResult()
        {
            // Act
            var result =  await _controller.Login();

            // Assert
           Assert.IsType<ViewResult>(result);
        }

        [Fact]
        public async Task SignUp_Returns_ViewResult()
        {
            // Act
            var result = await _controller.SignUpPage();

            // Assert
            Assert.IsType<ViewResult>(result);
        }

        [Fact]
        public async Task SignUp_NewUserCreation_Success()
        {
            // Arrange
            var inputUserData = new SignUpViewModel
            {
                Email = "arun1@gmail.com",
                Password = "Test@1234"
            };
       

            int createdUserId = 11;
                        
                      
            _mockUserService.Setup(service => service.IsUserExistsAsync(It.IsAny<string>()))
               .ReturnsAsync((string email) => null); 
           
            _mockUserService.Setup(service => service.CreateUserAsync(It.IsAny<User>()))
               .ReturnsAsync((User user) => 11);

            // Act
            var result = await _controller.SignUp(inputUserData);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal("/Views/Account/Login.cshtml", viewResult.ViewName);
        }

        [Fact]
        public async Task Login_User_Success()
        {
            // Arrange
            LoginViewModel inputUserData = new LoginViewModel();
            inputUserData.Email = "arun1@gmail.com";
            inputUserData.Password = "Test@1234";
            var mockHttpContext = new Mock<HttpContext>();
            var mockSession = new Mock<ISession>();


            int loginUserId = 1;
            User databaseUserData = new User(); ;
            databaseUserData.Email = "arun1@gmail.com";
            databaseUserData.Password = "Test@1234";
            string token = "AA7890uuiioop06879=";
            _mockUserService.Setup(service => service.AuthenticateUserAsync(inputUserData.Email, inputUserData.Password)).ReturnsAsync(databaseUserData);
            _mockJwtAuthenticationManager.Setup(service => service.GenerateToken(inputUserData.Email)).Returns(token);
            mockHttpContext.SetupGet(c => c.Session).Returns(mockSession.Object);

           
            // Simulate setting string "JwtToken" in session
          
            _controller.ControllerContext = new ControllerContext()
            {
                HttpContext = mockHttpContext.Object,
            };
            _controller.HttpContext.Session.SetString("JwtToken", token);

            // Simulate setting int "UserId" in session
            int userId = 123;
            _controller.HttpContext.Session.SetInt32("UserId", loginUserId);

            // Act
            var result = await _controller.Login(inputUserData);

            // Assert
            var redirectToActionResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", redirectToActionResult.ActionName);

        }
    }
}