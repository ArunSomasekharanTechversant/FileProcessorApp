1) Created console application(receive messages from the RabbitMQ queue and updates the database), Web application(contains sign up page, login page, homepage with file upload button and file status info  table)
2) Created the project using dapper, repository pattern, dependency injection and  created unit tests  using MOQ and Xunit
3) Please use the  users.csv file(firstname, lastname, age) in this zip
4) data is stored in the message queue of RabbitMQ in docker
5) Tables are created in sql database (local database), please change sql connection string in console and web application(appsettings file). table creation scripts are added in the script.
6) Make sure you start the docker with RabbitMQ before running the application 

Note:-this link(https://www.youtube.com/watch?v=gntSKlXedvE) can be used to set up RabbitMq in docker
--Dotnet framework is .NET 8.0

